import scrapy, re

import scrapy, re

class QuotesSpider(scrapy.Spider):

    name = 'BBC'
    start_urls = ['https://www.bbc.co.uk/news/uk-england-london-52089046',]


    def parse(self, response):

        header1 = response.xpath("//h1/text()").getall()
        paragraphs = response.xpath("//p/text()").getall()
        img_captions = response.xpath("//span[@class='media-caption__text']/text()").getall()

        yield {'header1:  ': header1,
               'paragraphs: ': paragraphs,
               'photo captions: ': img_captions,}