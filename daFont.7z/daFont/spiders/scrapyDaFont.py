import scrapy, re

###   ITEMS:    ###
class daFontItem(scrapy.Item):
    # define the fields for your item here like:
    # fontNames = scrapy.Field()
    # len_of_fontNames = scrapy.Field()
    #
    # studio = scrapy.Field()
    # len_of_studios = scrapy.Field()
    #
    # total_downloads = scrapy.Field()
    # len_of_total_downloads = scrapy.Field()
    #
    group = scrapy.Field()
    len_of_group = scrapy.Field()


###   SPIDER:   ###
class QuotesSpider(scrapy.Spider):

    name = 'daFont'
    start_urls = ['https://www.dafont.com/top.php?page=1&fpp=200',]


    def parse(self, response):
        def nextPages(self):
            next_page = response.xpath("//a[@title='Keyboard shortcut: Right arrow']/@href").get()
            next_page = response.urljoin(next_page)
            return scrapy.Request(next_page, callback=self.parse)

        def studios(self):

            studios_proper = []
            # studios_A = response.xpath("//div[@class='lv1left dfbg'][{0}]/a[2]/text()".format(a)).get() if response.xpath("//div[@class='lv1left dfbg'][173]/a[2]/text()").get() else 'no studio mentioned'
            for i in range(1,201):
                result = response.xpath("//div[@class='lv1left dfbg'][{0}]/a[2]/text()".format(i)).get() if response.xpath("//div[@class='lv1left dfbg'][{0}]/a[2]/text()".format(i)).get() else 'no studio mentioned'
                studios_proper.append(result)
            return studios_proper

        def total_downloads(self):
            total_downloads = response.xpath("//div[@class='lv2right']/span[@class='light']/text()").getall()
            #in next: we take total downloads, we extract firt number, remove (,), then convert it to integer to work with later in pandas:
            clean_downloads = [int(re.sub(',','', re.findall("(\d*.\d*)(?=\sdownloads)",x)[0])) for x in total_downloads]
            return clean_downloads


        #item setup
        item = daFontItem()

        # item['studio'] = studios(self)
        # item['len_of_studios'] = len(item['studio'])

        # item['total_downloads'] = total_downloads(self)
        # item['len_of_total_downloads'] = len(item['total_downloads'])

        item['group'] = response.xpath("//div[@class='lv1right dfbg']/a[1]/text()").getall()
        item['len_of_group'] = len(item['group'])


        # item['total_downloads'] = total_downloads(self)

        yield nextPages(self)
        yield item







        # item['len_of_fontNames'] = len(item['fontNames'])
        #
        # item['studio'] = studios(self)
        # item['len_of_studios'] = len(item['studio'])
        #
        # item['total_downloads'] = total_downloads(self)
        # item['len_of_total_downloads'] = len(item['total_downloads'])
        #
        # item['group'] = response.xpath("//div[@class='lv1right dfbg']/a[1]/text()").getall()
        # item['len_of_group'] = len(item['group'])




        # # NEXT PAGES
        # next_page = response.xpath("//a[@title='Keyboard shortcut: Right arrow']/@href").get()
        # next_page = response.urljoin(next_page)
        # yield scrapy.Request(next_page, callback=self.parse)















