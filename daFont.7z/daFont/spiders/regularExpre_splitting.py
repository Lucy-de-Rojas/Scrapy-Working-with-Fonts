import re
stringo = "love regex or hate regex, cant ignore regex"


result = re.findall("(?<!love|hate)\w+ ", stringo)

listo = []


for i in range(1,201):
    listo.append(i)


print(len(listo))