fonts = open("daFontResult-FontNames.csv", 'r')
studios = open("daFontResult-Studios.csv", 'r')
total_downloads = open('daFontResult-TotalDownloads.csv', 'r')
groups = open('daFontResult-Group.csv', 'r')


for i in fonts:
    font_names = i.split(',')

for i in studios:
    studios = i.split(',')

for i in total_downloads:
    total_downloads = i.split(',')


for i in groups:
    groups = i.split(',')


print(groups)
print(len(groups))






