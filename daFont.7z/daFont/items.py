# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class daFontItem(scrapy.Item):
    # define the fields for your item here like:
    fontNames = scrapy.Field()
    len_of_FontNames = scrapy.Field()

    studios = scrapy.Field()
    len_of_studios = scrapy.Field()

    total_donwloads = scrapy.Field()
    len_of_total_downloads = scrapy.Field()

    group = scrapy.Field()
    len_of_groups = scrapy.Field()

